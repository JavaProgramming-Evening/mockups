package com.example.phalla.typingracer;

/**
 * Created by Sony on 22/07/2016.
 */
public interface ModelAdapterClickListener {
    public void onCarModelClick(int carIndex);
}
